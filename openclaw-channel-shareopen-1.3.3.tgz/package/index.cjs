/**
 * ShareOpen Channel Plugin — Entry Point (CJS)
 *
 * Re-exports the ESM implementation for CommonJS consumers.
 * Use: const plugin = require("./index.cjs"); plugin(api);
 */
module.exports = require("./index.js");
