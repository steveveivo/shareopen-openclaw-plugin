// ShareOpen Channel Plugin — Setup Entry (CJS)
// Minimal setup for config validation and status checks

module.exports = {};
